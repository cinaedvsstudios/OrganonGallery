# Project brief — Asset Library & Review

Optional: fill in any answers you know, or give them directly in the chat. Blank fields mean unanswered, not permission to invent facts. "I'll provide it later", "use the default" and "not needed" are valid answers. The assistant should ask only the remaining relevant questions, then update this brief with decisions.

## Project and supplied content
- Project name and purpose:
- Intended audience and main action:
- Page/menu headings and ordered sections:
- Copy/content files and where each belongs:
- Logo, images/video/audio, captions and alt text:
- What should stay exactly as in the template:
- Requested changes only:

## Contact and destinations — only those present
- Contact email address(es):
- Each button/link label -> page, section, URL, file, dialog or action:
- Social/profile, booking, footer and privacy URLs:
- Form fields and delivery method/recipient (if any):

## Additional elements and final appearance
- Base template if this is an element package:
- Additional-element filenames and desired page/location/trigger:
- Content/data for each additional element; add or replace what:
- Final palette/style choice if packages differ:
- Mobile placement or other behavior changes:

## Relevant data or extension decisions
- What database or storage method is planned? Offer plain choices if undecided: session-only demo; saved in this browser/device; read a user-selected local file; import/upload a file; or connect to a server database/API. Ask for the engine/provider only when a database connection is actually needed.
- Does a selected file stay entirely on the computer, or get uploaded to a server? Which file formats, columns/schema, sample rows and size limits apply? Should edits save to the browser, an exported replacement file, the original file with permission, or the server? Never silently upload a local file.
- Is the information generic/public, internal, personal, or confidential? Who may view, add, edit, delete and export it? Is login needed, is it single-user or shared, and do users see different records? Hidden buttons are not access control.
- What unique IDs, relationships, validation, duplicate handling, merge/replace imports, backup/export and undo/audit requirements apply? Preserve all unrelated data when editing or importing.
- Explain the chosen storage behavior and its limits before wiring it up. Browser-local storage is not a secure multi-user database. Keep real private data and privileged credentials out of public source/downloads; use anonymized examples and proper server-side access checks where needed.

## This selection's open questions
Supply asset categories, metadata fields, review stages, sorting rules and approve/reject meanings. Where will files be stored and who may change review status?

## Delivery
- Where it should run (local browser, static host, existing app, extension, other):
- Existing project files or hosting constraints:
- Final output format:

## Decisions and TO PROVIDE items
- Confirmed decisions:
- Deferred item | placeholder/location in code | what is needed later:
- Connected features versus intentional demo/pending features:
