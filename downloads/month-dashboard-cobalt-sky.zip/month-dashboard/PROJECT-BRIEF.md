# Project brief — Month Dashboard

Optional: fill in any answers you know, or give them directly in the chat. Blank fields mean unanswered, not permission to invent facts. "I'll provide it later", "use the default" and "not needed" are valid answers. The assistant should ask only the remaining relevant questions, then update this brief with decisions.

## Project and supplied content
- Project name and purpose:
- Intended audience and main action:
- Page/menu headings and ordered sections:
- Copy/content files and where each belongs:
- Logo, images/video/audio, captions and alt text:
- What should stay exactly as in the template:
- Requested changes only:

## Contact and destinations — only those present
- Contact email address(es):
- Each button/link label -> page, section, URL, file, dialog or action:
- Social/profile, booking, footer and privacy URLs:
- Form fields and delivery method/recipient (if any):

## Additional elements and final appearance
- Base template if this is an element package:
- Additional-element filenames and desired page/location/trigger:
- Content/data for each additional element; add or replace what:
- Final palette/style choice if packages differ:
- Mobile placement or other behavior changes:

## Relevant data or extension decisions
- What is the real data source: manual entries, local/imported file, existing database or named API? Is it read-only reporting or does it edit records? Should information stay on this computer or be uploaded/shared?
- Define every KPI, chart series, unit, grouping, filter and total/average calculation. Ask how to treat missing versus zero values, date ranges, timezone, week start and refresh frequency. Do not invent plausible analytics.
- Who can view the reports and exports, and does the data include private information? Ask about login/roles and data storage only where needed.
- Confirm whether exports contain the displayed filtered scope or all records, and which file format is wanted. Keep filters, totals, charts and downloads consistent.

## This selection's open questions
Which summary panels and connected apps belong here? What are the task/reminder fields, priorities, recurrence and completion rules? Define Today/Week/Month ranges, timezone/week start and the source/calculation for every summary. Should reminders notify the user or remain an on-page list?

## Delivery
- Where it should run (local browser, static host, existing app, extension, other):
- Existing project files or hosting constraints:
- Final output format:

## Decisions and TO PROVIDE items
- Confirmed decisions:
- Deferred item | placeholder/location in code | what is needed later:
- Connected features versus intentional demo/pending features:
