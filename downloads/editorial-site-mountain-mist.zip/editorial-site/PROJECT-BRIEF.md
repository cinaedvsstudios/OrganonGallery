# Project brief — Editorial Site

Optional: fill in any answers you know, or give them directly in the chat. Blank fields mean unanswered, not permission to invent facts. "I'll provide it later", "use the default" and "not needed" are valid answers. The assistant should ask only the remaining relevant questions, then update this brief with decisions.

## Project and supplied content
- Project name and purpose:
- Intended audience and main action:
- Page/menu headings and ordered sections:
- Copy/content files and where each belongs:
- Logo, images/video/audio, captions and alt text:
- What should stay exactly as in the template:
- Requested changes only:

## Contact and destinations — only those present
- Contact email address(es):
- Each button/link label -> page, section, URL, file, dialog or action:
- Social/profile, booking, footer and privacy URLs:
- Form fields and delivery method/recipient (if any):

## Additional elements and final appearance
- Base template if this is an element package:
- Additional-element filenames and desired page/location/trigger:
- Content/data for each additional element; add or replace what:
- Final palette/style choice if packages differ:
- Mobile placement or other behavior changes:

## Relevant data or extension decisions
- For a simple content website, ask only for missing headings/copy, media, navigation and destinations. Do not ask database or account questions unless its real features need them.
- For every email/contact button ask for the recipient address; for every link/button ask whether it opens a page, section, external URL, download, dialog or action, and get its destination. Include social links, booking links, footer/privacy links and downloadable files.
- If there is a contact form, ask whether it should send email, store a request, open an email app, or remain a demo. Ask for recipient/service and required fields only if relevant. An email address alone does not configure form delivery.
- If this is an interactive web app, also ask where its data comes from, whether edits must persist, whether it is single-user/shared, and what external services/actions actually need to work.

## This selection's open questions
What are the top-level menus? For each menu, give the ordered slides, headline, body, image/alt text and button destination. Keep manual arrows/dots only, or is autoplay wanted? What should the contact view do?

## Delivery
- Where it should run (local browser, static host, existing app, extension, other):
- Existing project files or hosting constraints:
- Final output format:

## Decisions and TO PROVIDE items
- Confirmed decisions:
- Deferred item | placeholder/location in code | what is needed later:
- Connected features versus intentional demo/pending features:
