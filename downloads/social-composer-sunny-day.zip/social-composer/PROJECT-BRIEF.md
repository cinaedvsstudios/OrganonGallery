# Project brief — Social Composer

Optional: fill in any answers you know, or give them directly in the chat. Blank fields mean unanswered, not permission to invent facts. "I'll provide it later", "use the default" and "not needed" are valid answers. The assistant should ask only the remaining relevant questions, then update this brief with decisions.

## Project and supplied content
- Project name and purpose:
- Intended audience and main action:
- Page/menu headings and ordered sections:
- Copy/content files and where each belongs:
- Logo, images/video/audio, captions and alt text:
- What should stay exactly as in the template:
- Requested changes only:

## Contact and destinations — only those present
- Contact email address(es):
- Each button/link label -> page, section, URL, file, dialog or action:
- Social/profile, booking, footer and privacy URLs:
- Form fields and delivery method/recipient (if any):

## Additional elements and final appearance
- Base template if this is an element package:
- Additional-element filenames and desired page/location/trigger:
- Content/data for each additional element; add or replace what:
- Final palette/style choice if packages differ:
- Mobile placement or other behavior changes:

## Relevant data or extension decisions
- Confirm what the extension should actually do, which exact website URLs/domains it operates on, and whether it needs to read page content, change pages, access files, use clipboard/downloads, or call an API. Ask only about permissions required by those actions.
- Confirm how it opens and behaves: toolbar popup, side panel or separate window; whether work continues when it closes; and what happens after browser restart. Preserve this package's existing window type unless the user asks to change it.
- Ask whether data/settings are session-only, saved on this device, synced through Chrome, exported, or sent to a server. Identify accounts/authentication and sensitive data where relevant; do not request passwords or API secrets in chat uploads.
- Ask whether delivery is an unpacked personal extension or intended for store distribution; obtain the final name, icon and support/contact details if needed. Do not publish or submit merely because a build was requested.
- Retain Manifest V3, packaged local scripts and the least permissions needed. Do not add broad access to all sites by default. Use the background/service-worker lifecycle correctly for durable jobs; closing a popup must not silently lose work that was meant to continue.
- Test the actual native extension folder, not just its browser demo. Its extension/INSTALL.txt explains loading unpacked. Original automation/accounts are not included or connected.
- Implementation references: https://developer.chrome.com/docs/extensions/develop/concepts/declare-permissions and https://developer.chrome.com/docs/extensions/reference/api/sidePanel . Recheck current official API details when implementing real integrations.

## This selection's open questions
Which services/accounts should the side panel support, and is this a local draft composer or should it really publish? What formats, media limits, captions, saved tags and labels are needed? Define draft storage, scheduling timezone, approval step and actual publishing service/API. Should the panel work globally or only on named sites?

## Delivery
- Where it should run (local browser, static host, existing app, extension, other):
- Existing project files or hosting constraints:
- Final output format:

## Decisions and TO PROVIDE items
- Confirmed decisions:
- Deferred item | placeholder/location in code | what is needed later:
- Connected features versus intentional demo/pending features:
