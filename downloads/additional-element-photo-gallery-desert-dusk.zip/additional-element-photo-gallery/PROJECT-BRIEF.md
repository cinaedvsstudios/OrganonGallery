# Project brief — Photo Gallery

Optional: fill in any answers you know, or give them directly in the chat. Blank fields mean unanswered, not permission to invent facts. "I'll provide it later", "use the default" and "not needed" are valid answers. The assistant should ask only the remaining relevant questions, then update this brief with decisions.

## Project and supplied content
- Project name and purpose:
- Intended audience and main action:
- Page/menu headings and ordered sections:
- Copy/content files and where each belongs:
- Logo, images/video/audio, captions and alt text:
- What should stay exactly as in the template:
- Requested changes only:

## Contact and destinations — only those present
- Contact email address(es):
- Each button/link label -> page, section, URL, file, dialog or action:
- Social/profile, booking, footer and privacy URLs:
- Form fields and delivery method/recipient (if any):

## Additional elements and final appearance
- Base template if this is an element package:
- Additional-element filenames and desired page/location/trigger:
- Content/data for each additional element; add or replace what:
- Final palette/style choice if packages differ:
- Mobile placement or other behavior changes:

## Relevant data or extension decisions
- First identify the base website/app/database/extension being built. This is an ADDITIONAL ELEMENT, supplied to be integrated because it was not in the chosen base template. Do not replace the base project with this standalone element demo.
- Ask which page/view it belongs on, the exact location (for example below the hero, inside a sidebar, or opened by a named button), whether it replaces anything, and its intended content/data/actions.
- Ask how it should behave on mobile, whether it is always visible or opens on demand, and how its actions connect to the host. Ask about storage, accounts, GPS, files and external services only for controls that use them.
- If only element packages were uploaded, ask which existing project or base template to integrate into. Do not silently invent a whole website.

## This selection's open questions
Which host page/section should contain the gallery, and before or after which existing content? Supply image files or URLs, order, categories, captions, alt text and any credits. Should clicking show the lightbox, follow a URL, or do something else? Should visitors upload images or only view them?

## Delivery
- Where it should run (local browser, static host, existing app, extension, other):
- Existing project files or hosting constraints:
- Final output format:

## Decisions and TO PROVIDE items
- Confirmed decisions:
- Deferred item | placeholder/location in code | what is needed later:
- Connected features versus intentional demo/pending features:
