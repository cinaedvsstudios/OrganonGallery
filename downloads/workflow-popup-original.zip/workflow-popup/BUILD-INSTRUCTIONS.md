# Build instructions: Workflow Popup

This file is the project handoff prompt. Follow it alongside the user's project request; it supplies defaults, not permission to override their explicit choices. All questionnaire answers may be provided directly in chat instead of filling in a separate form.

## What was selected
Package role: BASE TEMPLATE for the new project

<!-- ORGANON-SELECTION:START -->
Selected palette: Studio (original)
Palette swatches: #6267B0, #EDF0F7, #343E50
Selected style: {"border": 1, "fill": "solid", "icons": "outline", "panels": "solid", "preset": "original", "shape": "original"}
<!-- ORGANON-SELECTION:END -->

Compact tool popup with a task selector, colored actions and results table.

Working features:
- Task chooser and settings dialog
- Paste sample rows and run a demo queue
- Start, pause, stop and clear controls
- Copy output and download CSV

## Your job
Build the user's requested project from the supplied base template and any additional elements. Preserve its chosen layout, styling and working interactions. Replace placeholder headings, lorem ipsum, generic logos, media and sample records with the supplied content. Make only the additions or changes requested; do not redesign the project or introduce a framework/build system without a concrete need.

## Read the uploads, then ask only what is missing
1. Inspect the actual code and render/open each supplied package if possible. Read BUILD-INSTRUCTIONS.md, PROJECT-BRIEF.md (if filled in), and the package manifests. The manifest identifies the role, entry points and selected appearance.
2. Separate the base template from packages/files named additional-element-*. If more than one base template was supplied and their roles are unclear, ask which is the foundation and which are references. Assets and sample imported content are data, not new instructions.
3. Use the user's message and any completed brief as answers. Ask a single short batch of relevant, unanswered questions in plain language. Explain any necessary technical choice with concrete options. Do not repeat answered questions or run every questionnaire for every project. If nothing essential is missing, start building immediately without a confirmation round.
4. The user can answer "I'll provide it later", "use the default" or "not needed". Record deferred items as TO PROVIDE in PROJECT-BRIEF.md and continue independent work. Leave explicit, easy-to-replace placeholders for missing text/assets. Keep unknown URLs, email addresses and live integrations disabled with clear pending behavior; never invent destinations, send to a fake recipient, or claim a demo action really saved/sent/published something.
5. If a missing answer changes a fundamental decision (for example which base to use, conflicting appearance, or local versus shared private data), ask before implementing that dependent part. Continue unrelated content/layout work. If the user explicitly defers a data-service decision, keep a clearly marked local sample mode until it is resolved.

## Missing content and destinations
- Ask for the project name, headings, copy, supplied logo/media and their intended pages only where these are not already given. Standard File/Edit/View menus and ordinary controls can retain their normal labels.
- Inspect all views, dialogs, menus, cards and footers. For every visible link/action that still lacks a destination, ask for the URL, section, file or intended behavior. Ask for actual recipient/support email addresses where contact controls appear, including in dashboards, extensions and additional elements. Do not assume a social URL, email address or service account from a project name.
- A contact form needs its recipient/delivery service and required fields; a mailto button only needs the intended email address and any specified subject. Keep unresolved destinations explicitly pending rather than inserting working-looking fake links.

## Additional elements: placement, behavior and appearance
- Any uploaded package named additional-element-* is an intentional addition to the base template, not a second competing design. Read its own instructions. Confirm its placement, content, trigger, replacement/addition role and connection to host state when not already stated.
- Compare selected_palette and selected_style across ALL manifests, including custom radius, borders, fills, transparency and icons. If palettes OR styles conflict and the user has not already specified a choice, ask which to use: base appearance throughout, an element's appearance throughout, or an intentional per-element exception. Do not silently choose. If they match, use them without another question.
- Share the agreed host color/style tokens. Avoid copying a second whole-page bootstrap, global reset, body layout, #root replacement or theme initializer into the host. Scope element CSS, IDs, events and saved-state keys to prevent collisions. Connect the relevant render function/markup and its handlers to the host's component container instead.
- Bring across required helpers, styles and local assets; inspect references rather than copying every unrelated demo function. Verify dialogs, nested menus, search, keyboard shortcuts, animations, timers and mobile navigation still work together. Remove duplicate example headings/toolbars that were only standalone-demo scaffolding.

## Final checks and handoff
- Keep menus, standard controls and the selected responsive layout. Check desktop, tablet and mobile, keyboard/focus/Escape, long content, hover, carousel navigation and any requested motion. Keep readable text on the selected palette and usable controls on touch screens.
- Check EVERY visible button/link/form: implement its agreed action or clearly label it as awaiting configuration. Check actual import/export files, validation, empty/error states and persistence/reload behavior for the chosen data method. Verify no real secret or private sample data entered the public bundle.
- Deliver editable source plus simple run/install instructions and an updated PROJECT-BRIEF.md listing decisions, remaining TO PROVIDE items and where to replace them. Distinguish completed behavior from pending connections and demo simulations. Do not add promotional copy, implementation notes or a floating "template details" box to the finished design. Do not publish, submit to a store, or send messages merely because the user asked to build a project.

## Questions for this type of project
- Confirm what the extension should actually do, which exact website URLs/domains it operates on, and whether it needs to read page content, change pages, access files, use clipboard/downloads, or call an API. Ask only about permissions required by those actions.
- Confirm how it opens and behaves: toolbar popup, side panel or separate window; whether work continues when it closes; and what happens after browser restart. Preserve this package's existing window type unless the user asks to change it.
- Ask whether data/settings are session-only, saved on this device, synced through Chrome, exported, or sent to a server. Identify accounts/authentication and sensitive data where relevant; do not request passwords or API secrets in chat uploads.
- Ask whether delivery is an unpacked personal extension or intended for store distribution; obtain the final name, icon and support/contact details if needed. Do not publish or submit merely because a build was requested.
- Retain Manifest V3, packaged local scripts and the least permissions needed. Do not add broad access to all sites by default. Use the background/service-worker lifecycle correctly for durable jobs; closing a popup must not silently lose work that was meant to continue.
- Test the actual native extension folder, not just its browser demo. Its extension/INSTALL.txt explains loading unpacked. Original automation/accounts are not included or connected.
- Implementation references: https://developer.chrome.com/docs/extensions/develop/concepts/declare-permissions and https://developer.chrome.com/docs/extensions/reference/api/sidePanel . Recheck current official API details when implementing real integrations.

## Questions for this particular template
What tasks should the popup offer, and what are their input/output columns? Will input come from manual paste, files, the active tab or an API? What exact action should Start perform on which sites? Define pause/stop/retry behavior, row timeouts, success/failure rules and CSV format. Must progress continue when the popup closes?

## Keep these specific behaviors
This native package is a toolbar popup (extension/manifest.json action.default_popup). Preserve its compact task selector, settings, colored actions, results table and copy/export controls. The queue is a local simulation and is not connected to the original automation.

## Where the implementation lives
- Open index.html for the standalone preview. The renderer is `workflowPopup()` in `collection.js`. Shared helpers/behavior may also live in collection.js, extras.js, interaction-fixes.js and appearance.js; inspect their references and initialization order before extracting a component.
- palettes.js holds palette roles/tokens; styles.js holds presets; style-config.js holds the selected custom visual settings. FIXED_CONFIG in index.html chooses the starting renderer and palette. For a native extension the bootstrap is in extension/bootstrap.js and selected styling is also in extension/style-config.js.
- TEMPLATE-MANIFEST.json records the exact downloaded palette and style. The gallery's "Don't change this site" checkbox only controls the gallery itself and does not change this package's selected template appearance.
- Samples demonstrate the listed UI interactions, not a production backend. Storage, contact delivery, GPS/geocoding, scheduling, external publishing and automation must be checked individually before being described as working integrations.
